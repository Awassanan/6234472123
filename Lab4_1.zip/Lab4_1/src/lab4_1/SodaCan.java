package lab4_1;

public class SodaCan {
    private double h;
    private double d;
    
    public SodaCan(double height,double diameter){
    h = height;
    d = diameter;
    }
    
    public double getVolume(){
    double volume = ((Math.PI)*(Math.pow(d/2, 2))*h);
    return volume;
    }
    
    public double getSurfaceArea(){
    double surface = (2*(Math.PI)*(d/2)*h)+(2*(Math.PI)*(Math.pow(d/2,2)));
    return surface;
    }
}
