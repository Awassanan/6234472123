package lab4_1;

import java.util.Scanner;

public class SodaCanTester {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter height: ");
        int height = in.nextInt();
        System.out.print("Enter diameter: ");
        int diameter = in.nextInt();
        SodaCan value = new SodaCan(height,diameter);
        System.out.println("Volume: "+value.getVolume());
        System.out.println("Surface area: "+value.getSurfaceArea());
    }
}
