package lab11_1;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue{
    private ArrayList<Object> product = new ArrayList<>();
    private ArrayList<Object> product2 = new ArrayList<>();
    private double total = 0;
    
    public SelfCheckOut(){}
    
    @Override
    public void enqueue(Object o)
    {
        product.add(o);
             if(o instanceof Product)
             {
                 System.out.println(((Product) o).getName() + " is added in queue");
                 product.remove(0);
             }
         product2.add(o);
    }
    
    @Override
    public void dequeue()
    {
        total += ((Product) product2.get(0)).getPrice();
        product2.remove(0);
    }
    
     public double getAmount()
    {
        return total;
    }
}
