/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2;

/**
 *
 * @author usci
 */
public class HollePrintor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String greeting = "Hello, World!";
        String greeting1 = greeting.replace("e","-");
        String greeting2 = greeting1.replace("o", "e");
        String greeting3 = greeting2.replace("-", "o");
        System.out.println(greeting3);
    }
    
}
