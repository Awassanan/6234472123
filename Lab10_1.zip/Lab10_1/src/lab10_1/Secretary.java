package lab10_1;

public class Secretary extends Employee implements Evaluation{
    private int typingSpeed;
    private int[] score;
    
     public Secretary(String name, int salary, int[] score, int type)
    {
        super(name, salary);
        typingSpeed = type;
        this.score = score;
    }
    
    @Override
    public double evaluate()
    {
        double totalScore = 0;
        for(int i = 0; i < score.length; i++)
        {
            totalScore += score[i];
        }
        return totalScore;
    }

    @Override
    public char grade(double totalScore)
    {
        int maxScore = 100;
        if(totalScore >= 90 && totalScore <= maxScore)
        {
            //เงินเดือนสูงสุดที่ให้ได้ไม่เกิน 18000
            this.setSalary(18000);
            return 'P';
        }
        return 'F';
    }
}
