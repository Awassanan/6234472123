package lab10_1;

public class Subject implements  Evaluation{
    private String subjName;
    private int[] score;
    
    public Subject(String subjName, int[] score)
    {
        this.subjName = subjName;
        this.score = score;
    }
    
    @Override
    public double evaluate()
    {
        double totalScore = 0;
        int count = 0;
        for(int i = 0; i < score.length; i++)
        {
            totalScore += score[i];
            count++;
        }
        double mean = totalScore/count;
        return mean;
    }

    @Override
    public char grade(double mean)
    {
        int maxScore = 100;
        if(mean >= 70 && mean <= maxScore)
        {
            return 'P';
        }
        return 'F';
    }
    
    @Override
    public String toString()
    {
        return subjName;
    }
}
