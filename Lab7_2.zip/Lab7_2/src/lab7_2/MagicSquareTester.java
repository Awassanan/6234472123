package lab7_2;

public class MagicSquareTester {
    public static void main(String[] args) {
       MagicSquare s = new MagicSquare(5);
       System.out.println(s.toString());
    }
    
}
