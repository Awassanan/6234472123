package lab7_2;

public class MagicSquare {
    private int n;
    private int[][]square;
    
    public MagicSquare (int n){
        this.n = n;
        int k, i, j;
        int iMax = n-1;
        int jMax = n-1;
        square = new int[n][n];
        i = iMax;
        j = n/2;
        square[i][j] = 1;

        for(k = 2; k <= n*n; k++){
            i++;
            if(i > iMax){i = 0;}

            j++;
            if(j > jMax){j = 0;}

            if(square[i][j]>0){
                i -= 2;
                if(i < 0){
                    i = iMax - 1;
                }

                j -= 1;
                if(j < 0){
                    j = jMax;
                }
            }
            square[i][j] = k;
        }
    }
    
    /*@Override*/
    public String toString(){
        String s = "";
        for(int[] e : square){
            for(int i : e){
            s+=i+"\t";
            }
        s+="\n\n";
        }
        return s;
    }
}
