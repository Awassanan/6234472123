/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

import java.util.GregorianCalendar;
import java.util.Calendar;
/**
 *
 * @author usci
 */
public class Gregorian {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar();// วันที่ปัจจุบัน
        GregorianCalendar myBirthday = new GregorianCalendar(2000,Calendar.APRIL, 7);
        cal.add(Calendar.DAY_OF_MONTH, 100); // cal จะมีค่าเปลี่ยนเป็นอีก 100 วันจากวันที่ปัจจุบัน
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);// cal จะมีค่าเปลี่ยนเป็นอีก 10000 วันจากวันเกิด
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH); //ได้วันที่ 1,2,3,…
        int month = cal.get(Calendar.MONTH); //ได้เลขเดือน โดยเดือนกราคมจะเป็นเลข 0
        int year = cal.get(Calendar.YEAR); //ได้เลขปีค.ศ.
        int weekday = cal.get(Calendar.DAY_OF_WEEK); //ได้เลขวันของสัปดาห์ โดย 1 คือ Sunday, 2 คือ Monday, . . . , 7 คือ Saturday
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year);
        
        int dayOfMonth2 = myBirthday.get(Calendar.DAY_OF_MONTH); //ได้วันที่ 1,2,3,…
        int month2 = myBirthday.get(Calendar.MONTH); //ได้เลขเดือน โดยเดือนกราคมจะเป็นเลข 0
        int year2 = myBirthday.get(Calendar.YEAR); //ได้เลขปีค.ศ.
        int weekday2 = myBirthday.get(Calendar.DAY_OF_WEEK); //ได้เลขวันของสัปดาห์ โดย 1 คือ Sunday, 2 คือ Monday, . . . , 7 คือ Saturday
        System.out.println(weekday2+" "+dayOfMonth2+" "+month2+" "+year2);
    }
    
}
