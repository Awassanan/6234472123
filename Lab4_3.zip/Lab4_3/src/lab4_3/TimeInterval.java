package lab4_3;

public class TimeInterval {
    private int initialStartTime, initialEndTime;
    private int startHour, startMinute, endHour, endMinute;
    private int finalStartTime, finalEndTime;
    
    public TimeInterval(int startTime,int endTime){
    initialStartTime = startTime;
    initialEndTime = endTime;
    
    startHour = initialStartTime/100;
    startMinute = initialStartTime%100;
    endHour = initialEndTime/100;
    endMinute = initialEndTime%100;
    
    finalStartTime = startMinute+(startHour*60);
    finalEndTime = endMinute+(endHour*60);
    }
    
    public int getHours(){
    return ((int)((finalEndTime-finalStartTime)/60));
    }

    public int getMinutes(){
    return ((finalEndTime-finalStartTime)%60);
    }
   }
