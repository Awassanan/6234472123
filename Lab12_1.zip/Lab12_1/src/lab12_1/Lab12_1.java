package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Lab12_1 {

    public static void main(String[] args) throws FileNotFoundException{
        File f = new File("input.txt");
        PrintWriter p = new PrintWriter(f);
        Scanner s = new Scanner(System.in);
        String text = "";
        while(!text.equals("quit"))
        {
            text = s.nextLine();
            if(!text.equals("quit"))
            {
                p.println(text); 
            }
        }
        p.close();
        
        Scanner read1 = new Scanner(f);
        String cha = "";
        int cntChar = 0;
        int totalChar = 0;
        while(read1.hasNext())
        {
            cha = read1.nextLine();
            cntChar = cha.length();
            totalChar += cntChar;    
        }
        System.out.println("Total characters : " + totalChar);
        
       Scanner read2 = new Scanner(f);
        int cntWord = 0;
        while(read2.hasNext())
        {
            read2.next();
            cntWord++;
        }
        System.out.println("Total words : " + cntWord);
        
        Scanner read3 = new Scanner(f);
        int cntLine = 0;
        while(read3.hasNextLine())
        {
            read3.nextLine();
            cntLine++;
        }
        System.out.println("Total lines : " + cntLine);
    }
    
}
