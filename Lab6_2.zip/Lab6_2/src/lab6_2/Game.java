package lab6_2;

import java.util.Random;
import java.util.Scanner;

public class Game {
    private int iChoose;
    private int comChoose;
    private int myScore;
    private int comScore;
    
    public String play(){
        Random computer = new Random();
        comChoose = computer.nextInt(3);
        Scanner in = new Scanner(System.in);
        System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
        iChoose = in.nextInt();
        
        while ((myScore - comScore < 2) && (comScore - myScore < 2)){
            if (iChoose != 0 && iChoose != 1 && iChoose != 2){
                System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
                iChoose = in.nextInt();
                switch (iChoose) {
                    case 0:
                        System.out.println("You enter: ROCK");
                        break;
                    case 1:
                        System.out.println("You enter: PAPER");
                        break;
                    case 2:
                        System.out.println("You enter: SCISSORS");
                        break;
                    default:
                        break;
                }
            }
            
            else {switch (iChoose) {
                    case 0:
                        System.out.println("You enter: ROCK");
                        break;
                    case 1:
                        System.out.println("You enter: PAPER");
                        break;
                    case 2:
                        System.out.println("You enter: SCISSORS");
                        break;
                    default:
                        break;
                }
            }
            
            switch (comChoose) {
                case 0:
                    System.out.println("Computer: ROCK");
                    break;
                case 1:
                    System.out.println("Computer: PAPER");
                    break;
                case 2:
                    System.out.println("Computer: SCISSORS");
                    break;
                default:
                    break;
            }
            
            switch (iChoose) {
                case 0:
                switch (comChoose) {
                    case 0:
                        System.out.println("It's a tie.");
                        myScore = myScore + 0;
                        comScore = comScore + 0;
                        break;
                    case 1:
                        System.out.println("You lose!");
                        comScore = comScore + 1;
                        break;
                    case 2:
                        System.out.println("You win!");
                        myScore = myScore + 1;
                        break;
                    default:
                        break;
                }
                break;

                case 1:
                switch (comChoose) {
                    case 0:
                        System.out.println("You win!");
                        myScore = myScore + 1;
                        break;
                    case 1:
                        System.out.println("It's a tie.");
                        myScore = myScore + 0;
                        comScore = comScore + 0;
                        break;
                    case 2:
                        System.out.println("You lose!");
                        comScore = comScore + 1;
                        break;
                    default:
                        break;
                }
                break;

                case 2:
                switch (comChoose) {
                    case 0:
                        System.out.println("You lose!");
                        comScore = comScore + 1;
                        break;
                    case 1:
                        System.out.println("You win!");
                        myScore = myScore + 1;
                        break;
                    case 2:
                        System.out.println("It's a tie");
                        myScore = myScore + 0;
                        comScore = comScore + 0;
                        break;
                    default:
                        break;
                }
                break;

                default:
                    break;}
        
        if ((myScore - comScore == 2) || ((myScore == 2) && (comScore == 0))){
        System.out.println("----------------------------------------");
        System.out.println("Congrats! You win.");
        System.out.println("User Score:" + myScore);
        System.out.println("Computer Score:" + comScore);
        break;
        }
        else if((comScore - myScore == 2) || ((myScore == 0) && (comScore == 2))){
        System.out.println("----------------------------------------");
        System.out.println("Too bad! You lose.");
        System.out.println("User Score:" + myScore);
        System.out.println("Computer Score:" + comScore);
        break;
        }
        
        System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
        iChoose = in.nextInt();
        comChoose = computer.nextInt(3);
        }
    return "";}
}
