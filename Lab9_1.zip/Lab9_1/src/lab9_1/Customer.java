package lab9_1;

public class Customer {
    private String name, tel;
    
    public Customer(){}
    
    public Customer(String name, String tel)
    {
        this.name = name;
        this.tel = tel;
    }
    
    public String getCustomerName()
    {
        return name;
    }
    
    public String getTel()
    {
        return tel;
    }
    
    @Override
    public String toString()
    {
        return this.getCustomerName() + " tel : " + this.getTel();
    }
}
