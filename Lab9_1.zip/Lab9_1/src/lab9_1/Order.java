package lab9_1;

import java.util.ArrayList;

public class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p = new ArrayList<>();
    
    public Order(Customer c)
    {
        this.c = c;
        id = ++cntOrder;
    }
    
    public void addPizza(Pizza piz)
    {
        p.add(piz);
    }
    
    public String getOrderDetail()
    {
        String detail = "Order id : " + id + "\n" + c.toString() + "\n";
        
        for(Pizza piz : p)
        {
            detail += piz.toString() + "\n";
        }
        detail += "Total pieces : " + p.size() + "\n";
        detail += "Total cost : " + this.calculatePayment();
        
        return detail;
    }
    
    public double calculatePayment()
    {
        double total = 0;
        double discount = 0;
        
        for(Pizza piz : p)
        {
            total += piz.getPrice();
        }
        
        //Downcasting
        if(c instanceof GoldCustomer)
        {
            GoldCustomer gold = (GoldCustomer) c;
            discount = gold.getDiscount();
        }
        
        return total*((100-discount)/100);
    }
}