package lab5_1;

import java.util.Scanner;

public class ZellerTester {
    public static void main(String[] args){
    Scanner in = new Scanner(System.in);
        System.out.print("Enter year (e.g. 2012): ");
        int y = in.nextInt();
        System.out.print("Enter month (1-12): ");
        int m = in.nextInt();
        System.out.print("Enter day of the month (1-31): ");
        int q = in.nextInt();
        Zeller input_value = new Zeller(y,m,q);
        System.out.println("Day of the week is "+input_value.getDayOfWeek());
    }
}
