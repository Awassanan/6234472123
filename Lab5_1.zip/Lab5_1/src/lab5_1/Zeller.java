package lab5_1;

enum Day {
   SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wednesday"),
    THURSDAY("Thurday"), FRIDAY("Friday"), SATURDAY("Saturday");

  private final String dayOfWeek;
  Day(String dayOfWeek) {
  this.dayOfWeek = dayOfWeek;
  }

  public String dayOfWeek() {
  return dayOfWeek;
  }

}

public class Zeller {
    private static int dayOfMonth;
    private static int month;
    private static int year;
    
    public Zeller(int y, int m, int q){
        
        dayOfMonth = q;
        switch (m) {
            case 1:
                month = m + 12;
                year = y - 1;
                break;
            case 2:
                month = m + 12;
                year = y - 1;
                break;
            default:
                month = m;
                year = y;
                break;
        }
    }
        
    public String getDayOfWeek()
    {
    int j = year / 100;
    int k = year % 100;
    int h = (dayOfMonth+((26*(month+1))/10)+k+(k/4)+(j/4)+(5*j))%7;
    
    String d = null;
    if (h == 0) {d = Day.SATURDAY.dayOfWeek();}
    else {switch (h)
    {
        case 1:
            d = Day.SUNDAY.dayOfWeek();
            break;
        case 2:
            d = Day.MONDAY.dayOfWeek();
            break;
        case 3:
            d = Day.TUESDAY.dayOfWeek();
            break;
        case 4:
            d = Day.WEDNESDAY.dayOfWeek();
            break;
        case 5:
            d = Day.THURSDAY.dayOfWeek();
            break;
        case 6:
            d = Day.FRIDAY.dayOfWeek();
            break;
        }}
    return d;
    }
}
