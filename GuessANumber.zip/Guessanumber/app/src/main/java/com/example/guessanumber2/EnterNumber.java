package com.example.guessanumber2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class EnterNumber extends AppCompatActivity {

    TextView textView2;
    EditText inputnumber;
    Button guess;
    int random_number = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enternumber);

        inputnumber = (EditText) findViewById(R.id.inputnumber);
        guess = (Button) findViewById(R.id.guess);
        textView2 = (TextView) findViewById(R.id.textView2);
        Random random = new Random();
        random_number = random.nextInt(100)+1;
    }

    public void onClickGuess (View v){

//        int random_number = random.nextInt(100)+1;
        int number = Integer.parseInt(inputnumber.getText().toString());
        if (number < random_number) {
            //textView2 = "Your guess is too low";
            textView2.setText("Your guess is too low");
            number = Integer.parseInt(inputnumber.getText().toString());
        }
        else if (number > random_number) {
            //textView2 = "Your guess is too high";
            textView2.setText("Your guess is too high");
            number = Integer.parseInt(inputnumber.getText().toString());
        }
        else if (number == random_number){
            Intent intent = new Intent(getBaseContext(), YouWon.class);
            startActivity(intent);
        }
    }
}
