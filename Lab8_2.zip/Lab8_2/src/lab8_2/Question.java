package lab8_2;

public class Question {
    public String text, answer;
   
    public Question(String text)
    {
        this.text = text;
    }
    
    public Question(){}
    
    public void setAnswer(String answer)
    {
        this.answer = answer;
    }
    
    public void setText(String text)
    {
        this.text = text;
    }
    
     public String getAnswer()
    {
        return answer;
    }
     
     public String getText()
    {
        return text;
    }
     
    public boolean checkAnswer(String response)
    {
        return response.equalsIgnoreCase(answer);
    }
    
    public void display()
    {
        System.out.println(text);
    } 
}
