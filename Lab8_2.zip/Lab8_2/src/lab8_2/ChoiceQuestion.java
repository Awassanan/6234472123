package lab8_2;

import java.util.ArrayList;

public class ChoiceQuestion extends Question{
    private ArrayList<String> choices = new ArrayList<>(4);

    public ChoiceQuestion(String text)
    {
        super(text);
    }
    
    public void addChoice(String choice, boolean truthValue)
    {
        choices.add(choice);
        if(truthValue)
        {
            super.setAnswer(choice);
        }
    }

     @Override
     public void display(){
         System.out.println(super.getText());
         for(int i = 1; i <= choices.size(); i++)
         {
             System.out.println(i + ". " + choices.get(i-1));
         }
    }
     
     @Override
     public boolean checkAnswer(String response)
    {
        int choice = Integer.parseInt(response);
        return choices.get(choice-1).equalsIgnoreCase(super.getAnswer());
    }
}
