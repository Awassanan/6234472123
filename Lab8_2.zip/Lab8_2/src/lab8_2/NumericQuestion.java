package lab8_2;

public class NumericQuestion extends Question{
    
    public NumericQuestion(String text)
    {
        super(text);
    }
    
    @Override
    public boolean checkAnswer(String response)
    {
        double ans = Double.parseDouble(super.getAnswer());
        double resp = Double.parseDouble(response);
        return (Math.abs(ans-resp)) <= 0.01;
    }
}
