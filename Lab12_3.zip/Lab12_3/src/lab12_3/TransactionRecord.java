package lab12_3;

public class TransactionRecord {
    private int acctNo;
    private double amtTrans;
    public TransactionRecord(int acctNo,double amtTrans){
        this.acctNo = acctNo;
        this.amtTrans = amtTrans;
    }
    public int getAcctNo(){ return acctNo; }
    public double getAmtTrans(){ return amtTrans; }
}
