package lab12_3;
import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public class FileMatch {

    public static void main(String[] args)
    {
        ArrayList<AccountRecord> accRec = new ArrayList<>();
        ArrayList<TransactionRecord> transRec = new ArrayList<>();
        // Update Balance
        try
        (
            Scanner readF1 = new Scanner(new File("C:\\Users\\User\\Desktop\\Lab 12\\Lab12_3\\src\\lab12_3\\master.txt"));
            Scanner readF2 = new Scanner(new File("C:\\Users\\User\\Desktop\\Lab 12\\Lab12_3\\src\\lab12_3\\trans.txt"));
        ) 
        {
            while (readF1.hasNextLine())
            {
                Scanner line = new Scanner(readF1.nextLine());
                accRec.add(new AccountRecord(Integer.parseInt(line.next()),line.next() + " " +line.next(),Double.parseDouble(line.next())));
            }
            
            while (readF2.hasNextLine())
            {
                Scanner line = new Scanner(readF2.nextLine());
                transRec.add(new TransactionRecord(Integer.parseInt(line.next()),Double.parseDouble(line.next())));
            }
            
            for (AccountRecord a : accRec)
            {
                for (TransactionRecord t : transRec)
                {
                    a.combine(t);
                }
            }
        }
        
        catch(IOException e)
        {
            System.out.println(e);
        }
        
        // Write Data
        try (RandomAccessFile r = new RandomAccessFile("C:\\Users\\User\\Desktop\\Lab 12\\Lab12_3\\src\\lab12_3\\newMaster.dat","rw"))
        {
            for (AccountRecord a : accRec)
            {
                // int 4 bytes
                r.writeInt(a.getAcctNo());
                // (char 2 bytes * ((space 2 bytes + totalNamelenght 30 bytes) = totalLenght 32 bytes)) = 64 bytes
                r.writeChar(' ');
                r.writeChars(a.getName());
                for(int i = 0;i < 30-(a.getName()).length();i++)
                {
                    r.writeChar(' ');
                }
                r.writeChar(' ');
                // double amtTrans 8 bytes + space 2 bytes = 10 bytes
                r.writeDouble(a.getBalance());
                r.writeChar(' ');
                // int transCnt 4 bytes + space 2 bytes = 6 bytes
                r.writeInt(a.getTransCnt());
                r.writeChars("\n");
            }
        }
        
        catch(IOException e)
        {
            System.out.println(e);
        }
        
        // Seek 
        try (RandomAccessFile r = new RandomAccessFile("C:\\Users\\User\\Desktop\\Lab 12\\Lab12_3\\src\\lab12_3\\newMaster.dat","rw"))
        {
            int line = 0;
            double sum = 0;
            int cnt = 0;
            while(r.readLine() != null)
            { 
                line++;
            }
            
            for (int i = 0; i < line; i++)
            {
                r.seek(getPointerBalance(i));
                sum+=r.readDouble();
                r.seek(getPointerTransaction(i));
                if (r.readInt()==0)
                {
                    cnt++;
                }
            }
            System.out.println("Total Account Record : " + line);
            System.out.println("Total balance : " + sum);
            System.out.println("No transaction : " + cnt + " account.");
        }
        
        catch(IOException e)
        {
            System.out.println(e);
        }
    }
    
    public static int getPointerTransaction(int line)
    {
        //int acctNo 2 bytes + ((char 2 bytes * ((space 2 bytes + totalNamelenght 30 bytes) = totalLenght 32 bytes)) = 64 bytes) +  ((space 2 bytes + double amtTrans 8 bytes) = 10 bytes) = 78 bytes
        //int acctNo 2 bytes + ((char 2 bytes * ((space 2 bytes + totalNamelenght 30 bytes) = totalLenght 32 bytes)) = 64 bytes) +  ((space 2 bytes + double amtTrans 8 bytes) = 10 bytes) + space 2 bytes + int transCNT 4 bytes = 84 bytes
        return 78+(line*84);
    }
    
    public static int getPointerBalance(int line)
    {
        //int acctNo 2 bytes + ((char 2 bytes * ((space 2 bytes + totalNamelenght 30 bytes) = totalLenght 32 bytes)) = 64 bytes) = 68 bytes
        //int acctNo 2 bytes + ((char 2 bytes * ((space 2 bytes + totalNamelenght 30 bytes) = totalLenght 32 bytes)) = 64 bytes) +  ((space 2 bytes + double amtTrans 8 bytes) = 10 bytes) + space 2 bytes + int transCNT 4 bytes = 84 bytes
        return 68+(line*84);
    }
}
