package lab5_2;

import java.awt.geom.Point2D;

public class Line {
    private double m,b,x;
    
    public Line(double a){
        this.x = a;
        this.m = Double.NaN;
        this.b = Double.NaN;
    }
        
    public Line(double m,double b){
        this.x = Double.NaN;
        this.m = m;
        this.b = b;
    }
   
    
    public Line(double x,double y, double m){
        this.x = Double.NaN;
        this.m = m;
        this.b = (-(m*x))+y;
    }
    
    public Line(double x1,double y1,double x2, double y2){
        
        if(x2-x1 != 0)
        {
            this.m = (y2-y1)/(x2-x1);
        }
        else
        {
            this.m = Double.NaN;
        }
        this.x = Double.NaN;
        this.b = (-(m*x1))+y1;
    }
    

    
   public boolean isParallel(Line line2){
        boolean truthvalue = false;
        if(Double.isNaN(this.m)&Double.isNaN(line2.m)){
            truthvalue = true;
        }else truthvalue = this.m == line2.m;
        return truthvalue;
    }
    public boolean equals(Line line2){
        boolean truthvalue = false;
        if(Double.isNaN(this.m)&&Double.isNaN(line2.m)){
            if((Double.isNaN(this.x)&&Double.isNaN(line2.x))&&(Double.isNaN(this.b)&&Double.isNaN(line2.b)))
            {
               truthvalue = false;
            }
            else
            {
               truthvalue = true; 
            }
            
        }else {
            truthvalue = this.m == line2.m & this.b == line2.b;
        }
        return truthvalue;
    }
    
    public boolean isIntersect(Line line2){
        return !this.isParallel(line2);
    }

    public Point2D.Double getIntersectionPoint(Line line2){
        double coordinateX = 0;
        double coordinateY = 0;
        Point2D.Double line = new Point2D.Double();
        if(Double.isNaN(line2.m) & Double.isNaN(line2.b)){
            coordinateX = line2.x;
            coordinateY = (this.m*coordinateX)+this.b;
            line.setLocation(coordinateX, coordinateY);                  
        }else if(Double.isNaN(line2.x) & Double.isNaN(this.x)){
            coordinateX = (line2.b-this.b)/(this.m-line2.m);
            coordinateY = (this.m*coordinateX)+this.b;
            line.setLocation(coordinateX, coordinateY);
        }else if (Double.isNaN(this.m) & Double.isNaN(this.b)){
            coordinateX = this.x;
            coordinateY = (line2.m*coordinateX)+line2.b;
            line.setLocation(coordinateX, coordinateY);
        }
        return line;
    }
    }

    
    

