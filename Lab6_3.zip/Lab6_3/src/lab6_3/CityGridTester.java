package lab6_3;

public class CityGridTester {
    public static void main(String[] args) {
        CityGrid start = new CityGrid(10);
        start.walk();
}
}
