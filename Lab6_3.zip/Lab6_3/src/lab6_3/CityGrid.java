package lab6_3;

import java.util.Random;

public class CityGrid {
    private int xCoor;
    private int yCoor;
    private int gridSize;
    
    public CityGrid (int gridSize){
    this.gridSize = gridSize;
    xCoor = this.gridSize/2;
    yCoor = this.gridSize/2;
    }
    
    public void walk(){ 
    int count = 0;
    int step = 0;
    int totalStep=0;
    int maximumStep=0;
 while(count<10000){
            while(step<1000){
                Random rd = new Random();
                int move = rd.nextInt(4);
                if (move == 0) yCoor--;
                else if (move == 1) yCoor++;
                else if (move == 2) xCoor--;
                else if (move == 3) xCoor++;
                step++;
                
                if (!isInCity()){
                    step--;
                    totalStep += step;
                    if(maximumStep<step)
                    {
                        maximumStep = step;
                    }
                    step=0;
                    reset();
                    break;
                }
            }
        count++;
 }
    System.out.printf("Average number of steps that a person can take and is still in the city: %.2f \n" , totalStep/10000.0);
    System.out.println("Maximum number of steps that a person can take and is still in the city: " + maximumStep);
    }
    
    public boolean isInCity(){
    boolean inCity = false;
    if (yCoor > gridSize || yCoor < 0 || xCoor > gridSize || xCoor < 0) inCity = false;
    else inCity = true;
    return inCity;
    }
    
    public void reset(){
    xCoor = gridSize/2;
    yCoor = gridSize/2;
    }
}