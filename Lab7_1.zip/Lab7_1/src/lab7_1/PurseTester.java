package lab7_1;

public class PurseTester {
    public static void main(String[] args) {
        Purse purse1 = new Purse();
        Purse purse2 = new Purse();
        purse1.addCoin("Quarter");
        purse1.addCoin("Dime");
        purse1.addCoin("Nickel");
        purse1.addCoin("Dime");
        purse1.reverse();
        System.out.println("Purse1: " + purse1.toString());
        System.out.println("Purse1 reversed: " + purse1.reverseToString());
        
        purse2.addCoin("Dime");
        purse2.addCoin("Nickel");
        purse2.reverse();
        System.out.println("\nPurse2: " + purse2.toString());
        System.out.println("Purse2 reversed: " + purse2.reverseToString());
        purse1.transfer(purse2);
        System.out.println("\nPurse1 transferred: " + purse1);
        System.out.println("Purse2 transferred: " + purse2);
        
        System.out.println("\nDoes purse1 and purse2 have the same coins?: " + purse1.sameCoins(purse2));
        System.out.println("Does purse1 and purse2 have the same coins\' ordering?: " + purse1.sameContents(purse2));
        
        
    }
}
