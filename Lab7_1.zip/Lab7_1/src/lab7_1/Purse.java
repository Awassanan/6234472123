package lab7_1;

import java.util.ArrayList;
import java.util.Arrays;

public class Purse {
    public ArrayList<String> purse = new ArrayList<>();
    public ArrayList<String> reverse = new ArrayList<>();
    public void addCoin(String coinName){
        purse.add(coinName);
    }
        

    public String toString(){
        return "Purse" + purse.toString();
    }
    
    public String reverseToString(){
        return "Purse" + reverse.toString();
    }
    
    
    
    public ArrayList<String> reverse(){
        for(int i = 0; i < purse.size(); i++){
            reverse.add("");
        }
        
        int j = 0;
        for(int i = purse.size()-1; i >= 0; i--){
            reverse.set(i, purse.get(j++));
        }
        
        return reverse;
    }
    
    public void transfer(Purse other){
        for(int i = 0; i < purse.size(); i++){
            other.purse.add(purse.get(i));
        }
        
        purse = new ArrayList<>();
//        int size = purse.size();
//        for(int i = 0; i < size; i++){
//            purse.remove(0);
//        }
    }
    
    public boolean sameContents(Purse other){
        if(purse.size() != other.purse.size()){return false;}
        
        for(int i = 0; i < purse.size(); i++){
            if(!purse.get(i).equals(other.purse.get(i))){return false;}
        }
        return true;
    }
    
    public boolean sameCoins(Purse other){
        int[] thisPurse = new int[4];
        int[] otherPurse = new int[4];
        
        if(purse.size()!= other.purse.size()){return false;}
        
        for(int i = 0; i < purse.size(); i++){
            String coinType = this.purse.get(i);
            switch(coinType){
                case "Penny":
                    thisPurse[0] += 1;
                    break;
                case "Nickel":
                    thisPurse[1] += 1;
                    break;
                case "Dime":
                    thisPurse[2] += 1;
                    break;
                case "Quarter":
                    thisPurse[3] += 1;
                    break;
            }
        }
        
        for(int i = 0; i < purse.size(); i++){
            String coinType = other.purse.get(i);
            switch(coinType){
                case "Penny":
                    otherPurse[0] += 1;
                    break;
                case "Nickel":
                    otherPurse[1] += 1;
                    break;
                case "Dime":
                    otherPurse[2] += 1;
                    break;
                case "Quarter":
                    otherPurse[3] += 1;
                    break;
            }
        }
        
        if(Arrays.equals(thisPurse, otherPurse)){return true;}
        else{return false;}
    }
}
