package lab8_1;

public class Truck extends Car{
    private double M_weight;
    private double weight;
    
    public Truck(double gas, double efficiency, double M_weight, double weight)
    {
        super(gas,efficiency);
        if(weight > M_weight)
        {
            this.weight = M_weight;
            this.M_weight = M_weight;
        }
        
        else
        {
            this.weight = weight;
            this.M_weight = M_weight;
        }
    }
    
    @Override
    public void drive(double distance)
    {
         if(weight < 1)
         {
             double gasUse = distance/efficiency;
             if(gasUse > gas) System.out.println("You cannot drive too far, please add gas");
             else {gas = gas - gasUse;}
         }

         else if(weight >= 1 && weight <= 10)
         {
             double gasUse = distance/efficiency + ((distance/efficiency)*0.1) ;
             if(gasUse > gas) System.out.println("You cannot drive too far, please add gas");
             else {gas = gas - gasUse;}
         }

         else if(weight >= 11 && weight <= 20)
         {
             double gasUse = distance/efficiency + ((distance/efficiency)*0.2) ;
             if(gasUse > gas) System.out.println("You cannot drive too far, please add gas");
             else {gas = gas - gasUse;}
         }

         else if(weight > 20)
         {
             double gasUse = distance/efficiency + ((distance/efficiency)*0.3) ;
             if(gasUse > gas) System.out.println("You cannot drive too far, please add gas");
             else {gas = gas - gasUse;}
         }
    }
}
    
    
    

