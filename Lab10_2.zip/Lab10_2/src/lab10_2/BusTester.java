package lab10_2;

import java.util.ArrayList;

public class BusTester {
    public static void main(String[] args) {
        ArrayList <Bus> arr = new ArrayList<>();
        Hybrid bus1 = new Hybrid(150, 1, 600, 45, 1.2*10e6);
        CNGBus bus2 = new CNGBus(200, 2, 50, 1*10e6);
        arr.add(bus1);
        arr.add(bus2);
        
        for(Bus bus : arr)
        {
            System.out.println("ID: " + bus.getID());
            
            if(bus instanceof  CNGBus)
            {
                CNGBus cngBus;
                cngBus = (CNGBus) bus;
                System.out.println("Emission Tier: " + cngBus.getEmissionTier());
            }
            
            if(bus instanceof  Hybrid)
            {
                Hybrid hybridBus;
                hybridBus = (Hybrid) bus;
                System.out.println("Emission Tier: " + hybridBus.getEmissionTier());
            }
            System.out.println("Accel: " + bus.getAccel());
        }
    }
}
