package lab10_2;

public interface LiquidFuel {
    double getRange();
    int getEmissionTier();
}
