package lab4_2;

public class DigitExtractor {
    private int digit;
    
    public DigitExtractor(int anInteger){
    digit = anInteger;
    }
    
    public int nextDigit(){
    int temp = digit%10;
    digit = digit/10;
    return temp;
    }
}
