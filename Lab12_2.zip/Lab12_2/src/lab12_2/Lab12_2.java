package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class  Lab12_2{

    public static void main(String[] args){
        ArrayList <String> words = new ArrayList <> ();
        try
        {
            File f = new File("C:\\Users\\User\\Desktop\\Lab 12\\Lab12_2\\src\\lab12_2\\wordlist.txt");
            Scanner in = new Scanner(f);
            String word;
            while (in.hasNext())
            {
                word = in.next();
                words.add(word);
            }
        }
        
        catch (FileNotFoundException e)
        {
            System.out.println(e);
        }
        
        System.out.print("Enter a sentence: ");
        Scanner sentence = new Scanner(System.in);
        String text = sentence.nextLine();
        Scanner t = new Scanner(text);
        System.out.println("Words not contained: ");
        boolean isNotContain = false;
        while(t.hasNext()){
            String inText = t.next();
            if (!words.contains(inText))
            {
                System.out.println(inText);
                isNotContain = true;
            }
        }
        if (!isNotContain)
        {
            System.out.println("N/A");
        }
    }
}