package lab6_1;

public class CannonBallTester {
    public static void main(String[] args) {
    CannonBall ball = new CannonBall(100); //กำหนดความเร็วตั้งต้นให้ลูกกระสุนปืนใหญ่มีค่าเป็น 100 m/sec
    ball.simulatedFlight();
    System.out.printf("Distance from calculus equation: %.3f\n",ball.calculusFlight(ball.getSimulatedTime()));
    }
}
