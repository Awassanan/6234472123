package lab6_1;

public class CannonBall {
    private double initV;
    private double simS;
    private double simT;
    public static final double g = 9.81;
    private double keepInitV;
    
    public CannonBall(double v0){
    initV = v0;
    keepInitV = v0;
    }
    
    public void simulatedFlight(){
        double deltaT = 0.01;
        int count = 0;
        int sec = 0;
        for(double v = initV; v > 0; v = v-(g*deltaT)){
            double deltaS = v * deltaT;
            simS += deltaS;
            count++;
            if (count % 100 == 0){
                sec++;
                System.out.printf("Distance on " + sec + " sec: %.3f\n", simS);
            }
        simT = count;
        }
        simT = simT / 100;
        System.out.printf("Final distance: %.3f Total time: %.2f \n", simS,simT);
    }
    
    public double getSimulatedDistance() {
    return simS;
    }
    
    public double calculusFlight(double t){
    double s = (-0.5*g*(Math.pow(t, 2))) + (keepInitV * t);
    return s;
    }
    
    public double getSimulatedTime(){
    return simT;
    }
}
