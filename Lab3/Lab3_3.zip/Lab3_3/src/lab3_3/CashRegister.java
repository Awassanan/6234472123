/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

import java.text.DecimalFormat;

/**
 *
 * @author usci
 */
public class CashRegister {
    private double total;
    private double payment;
    private double totaltax;
    private double tax;
    public CashRegister(double initialtax){tax = initialtax;}

    public void recordPurchase(double cost){
    total += cost;
    }
    
    public void enterPayment(double initialpayment){
    payment += initialpayment;
    }
    
    public String giveChange(){
    double change = payment - total;
    payment = 0;
    total = 0;
    DecimalFormat df = new DecimalFormat("#.#");
    String roundchange = df.format(change);
    return roundchange;
    }
      
    public void recordTaxablePurchase(double cost){
    total += cost+(cost*(tax/100));
    totaltax += cost*(tax/100);
    }
    
    public double getTotalTax(){
    return totaltax;
    }
    
    

    /**
     * @param args the command line arguments
     */
    
    
}
