/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author usci
 */
public class LetterPrinter {
    public static void main(String[] ars){
    Letter letter = new Letter("Clarissa", "Jade");
    letter.addLine("We must find Simon quickly.");
    letter.addLine("He might be in danger.");
    System.out.println(letter.getText());
    
    }
    
}
