/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_2;

/**
 *
 * @author usci
 */
public class Letter {
    public String send;
    public String receive;
    public String text;
    
    public Letter(String from, String to){
        send = from;
        receive = to;
        text = "";
    }
    public void addLine(String line){text += line+"\n";}
    
    public String getText(){
    return "Dear"+" "+receive+":"+"\n"+"\n"+text+"\n"+"Sincerely,"+"\n"+"\n"+send;
    }

    /**
     * @param args the command line arguments
     */
        
}
