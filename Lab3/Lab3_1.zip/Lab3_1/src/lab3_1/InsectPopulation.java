/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_1;

/**
 *
 * @author usci
 */
public class InsectPopulation {
    private double population;
    public InsectPopulation(double initialPopulation){population = initialPopulation;}
    
    public void breed(){population = population*2;}
    
    public void spray() {population = population*0.9;}
    
    public double getNumInsect() {return population ;}
    
    
}
